

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div style="float:right;" class="mb-5">
            <a href="<?php echo e(route('position.create')); ?>" class="btn btn-primary">Tambah Position</a>
        </div>
        <table id="user-table" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Link</th>
                    <th>Aksi</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->link); ?></td>
                        <td><?php echo e(ucfirst($item->status)); ?></td>
                        <td>
                            <a href="/sosmed/<?php echo e($item->id); ?>/edit" class="btn btn-info">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<!-- jQuery (load first!) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

<!-- Optional: Bootstrap DataTables styling (if used) -->


<!-- Stack for child views -->

<script>
    $(document).ready(function () {
        $('#user-table').DataTable({});
        
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Sukses!',
                text: '<?php echo e(session('success')); ?>',
                showConfirmButton: false,
                timer: 2000
            });

        <?php endif; ?>

        <?php if(session('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: '<?php echo e(session('error')); ?>',
                showConfirmButton: false,
                timer: 2000
            });

        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e_gapura\resources\views/pages/sosmed/index.blade.php ENDPATH**/ ?>