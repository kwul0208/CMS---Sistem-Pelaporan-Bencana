

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <a href="<?php echo e(route('sosmed.index')); ?>" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i> Kembali</a>
        <form method="POST" action="<?php echo e(isset($model) ? route('sosmed.update', $model) : route('sosmed.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if(isset($model)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
            <div class="col-12">
                <div class="form-group">
                    <label for="name">Nama</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e($model->name ?? ''); ?>" placeholder="Nama" required>
                </div>
                <div class="form-group">
                    <label for="name">Link</label>
                    <input type="text" class="form-control" id="link" name="link" value="<?php echo e($model->link ?? ''); ?>" placeholder="Link" required>
                </div>
                <div class="form-group">
                    <label for="parent_id">Status</label>
                    <select class="form-control" id="parent_id" name="parent_id">
                        <option value="active" <?php echo e(isset($model) && $model->status == 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="not active" <?php echo e(isset($model) && $model->status == 'not active' ? 'selected' : ''); ?>>Not Active</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form> 
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e_gapura\resources\views/pages/sosmed/form.blade.php ENDPATH**/ ?>